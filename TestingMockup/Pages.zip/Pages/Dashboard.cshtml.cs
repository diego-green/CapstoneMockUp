using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

[AllowAnonymous]
public class DashboardModel : PageModel
{
    public void OnGet() { }
}
