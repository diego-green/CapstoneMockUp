using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TestingMockup.Pages.Shared
{
    public class _AuthLinksModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
